import { BaseWidget, jsx, React, type AllWidgetProps } from 'jimu-core'
import { JimuMapView, JimuMapViewComponent } from "jimu-arcgis";

export default class Widget extends BaseWidget<AllWidgetProps<{}>, any> {
    constructor(props: AllWidgetProps<any>) {
      super(props);
      this.state = {
        selectedMapView: null,
        rows: {} // Now an object grouped by district
      };
    }

  onActiveViewChange = (jimuMapView: JimuMapView) => {
    if (jimuMapView) {
      console.log("Selected Map:", jimuMapView);
      this.setState({ selectedMapView: jimuMapView }, () => {
        this.listenForLayerUpdates();
      });
    }
  };

  listenForLayerUpdates = () => {
    const { selectedMapView } = this.state;

    if (!selectedMapView) {
      console.log("No selected map view");
      return;
    }
    
    const featureLayers = selectedMapView.view.map.layers.filter(
      (layer) => layer.type === "feature"
    );

    featureLayers.forEach((layer) => {
      layer.watch("timeExtent", (timeExtent) => {
        console.log("Layer Filter Changed....,", timeExtent)

        featureLayers.forEach((layer) => {
          layer.when(() => {
            console.log("Time Extent:", timeExtent);
            layer.queryFeatures({
              where: layer.definitionExpression || "1=1",
              outFields: ["Name", "Stage_Gate", "District"],
              returnGeometry: false,
              timeExtent: timeExtent || null
            }).then((featureSet) => {
              if (featureSet.features.length === 0) return;

              const groupedByDistrict = featureSet.features.reduce((acc, feature) => {
                const { Name, Stage_Gate, District } = feature.attributes;

                if (!acc[District]) {
                  acc[District] = {}; // Create district group if not exists
                }

                if (!acc[District][Name] || acc[District][Name] < Stage_Gate) {
                  acc[District][Name] = Stage_Gate; // Store the highest Stage_Gate for each Name
                }

                return acc;
              }, {});

              this.setState({ rows: groupedByDistrict });
            });
          });
        });
      });
    });
  };



  

  render() {
    const { rows } = this.state;
    const stageGateColorMapping = {
      1: "#26F2FF", // Cyan
      2: "#FFFF62", // Light Yellow
      3: "#FFD3FF", // Pink
      4: "#FFFF55", // Yellow
      5: "#FFFF62", // Light Yellow
      6: "#FFD3FF", // Light Pink
      7: "#FF7F7F", // Red
    };
    
    const getBarColor = (stageGate: number) => {
      return stageGateColorMapping[stageGate] || "gray"; // Default to gray if no match
    };


    return (
      <div style={{ padding: '2% 5%', textAlign: 'left' }}>
        <h3 style={{ fontSize: '18px', fontWeight: 'bold', marginBottom: '5px' }}>
          Stage Gates by District
        </h3>
        
        {Object.keys(rows).length > 0 ? (
          <div style={{ display: 'flex', justifyContent: 'space-between', gap: '40px', alignItems: 'flex-end' }}>
            {Object.entries(rows).map(([district, names]) => (
              <div key={district} style={{ display: 'flex', flexDirection: 'column', alignItems: 'space-between' }}> 
                <div style={{ display: 'flex', gap: '15px', alignItems: 'flex-end', height: '200px', borderBottom: '0.5px solid #333', padding: '10px', marginTop: '10px', borderRight: '0.5px solid #333'}}>
                  {Object.entries(names).map(([name, stageGate]) => {
                    const barHeight = Math.min((stageGate / 7) * 100, 100); // Cap max height at 100px
                    return (
                      <div key={name} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', position: 'relative', marginRight: '15px' }}>
                        <div
                          style={{
                            height: `${barHeight}px`,
                            width: '20px',
                            backgroundColor: getBarColor(stageGate), 
                            transition: 'height 0.3s ease',
                            overflow: 'visible',
                            whiteSpace: 'nowrap'
                          }}
                        />
                        <div style={{
                          position: 'absolute',
                          left: '-20px', // Position slightly away from the bar
                          bottom: '0',
                          writingMode: 'vertical-rl', // Vertical text
                          textAlign: 'center',
                          fontSize: '14px',
                          fontWeight: 'bold',
                          color: '#fff',
                          transform: 'rotate(180deg)', // Keep text readable
                          whiteSpace: 'nowrap', // Prevent wrapping
                          minWidth: '20px', // Ensure the text doesn't squeeze into the bar
                          overflow: 'visible', // Ensure visibility even if bar is small
                        }}>
                          {name}
                        </div>
                      </div>
                    );
                  })}
                </div>
                <h4 style={{ fontSize: '18px', color: '#e0e0e0', marginTop: '10px' }}>{district}</h4>
              </div>
            ))}
          </div>
        ) : (
          <p style={{ fontSize: '18px', color: '#888' }}>No data available. Select a map.</p>
        )}

        <JimuMapViewComponent
          useMapWidgetId={this.props.useMapWidgetIds[0]}
          onActiveViewChange={this.onActiveViewChange}
        />
      </div>
    );
  }
}
